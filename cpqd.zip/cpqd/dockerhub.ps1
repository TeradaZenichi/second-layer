docker pull zenichi/second-layer-phpmyadmin
docker pull zenichi/second-layer-mysql
docker pull zenichi/second-layer-nginx
docker pull zenichi/second-layer-python
docker-compose up --remove-orphans -d