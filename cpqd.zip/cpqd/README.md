# Guia Camada Secundária

* Passo 1: Baixe as imagens conforme os scripts dockerhub.ps1 e dockerhub.sh

* Passo 2: Use o arquivo docker-compose.yml para colocar os containers online

* Passo 3: Verifique se há uma mensagem, exibida a cada um minuto, sinalizando o status "ok"

* Passo 4: Verifique o funcionamento da documentação dos endpoints em http://localhost:8080